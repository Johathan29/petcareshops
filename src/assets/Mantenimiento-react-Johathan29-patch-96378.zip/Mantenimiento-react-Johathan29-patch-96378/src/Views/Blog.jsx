export default function BlogPage(){
    return(
        <>
        <h1>Blog</h1>
        </>
    )
}