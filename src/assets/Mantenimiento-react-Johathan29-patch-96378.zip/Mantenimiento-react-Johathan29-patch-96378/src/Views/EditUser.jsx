export default function EditUser(){
    return(
        <>
        <h1 className="!text-gray-500">
            edit user
        </h1>
        </>
    )
}