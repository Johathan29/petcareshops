export default function NoPage(){
    return(
        <>
        <h1>Pagina no encontrada</h1>
        </>
    )
}